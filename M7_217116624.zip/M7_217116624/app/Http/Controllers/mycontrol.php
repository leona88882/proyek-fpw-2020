<?php

namespace App\Http\Controllers;
use App\users;
use App\gambar;
use Illuminate\Http\Request;
use Illuminate\Queue\Jobs\RedisJob;

class mycontrol extends Controller
{
    public function olahlogin(Request $data){

        $result = users::where('email', '=', $data->input('email'))->first();
        if($data->input('email')=='admin'&&$data->input('password')=='admin'){
            return redirect('/admin');
        }
        else if($result===null){

        $data->merge(['tipe'=>0]);

           users::create($data->all());
            return redirect('/home');
        }else{
            $result = users::where('email', '=', $data->input('email'))->where('password','=',$data->input('password'))->first();
            if($result==null){
                return redirect('/');
            }
            else{
                return redirect('/home');
            }
        }
    }
    public function loadadmin(){
        $result= gambar::all();
        return view('admin',['result'=>$result]);
    }
}
