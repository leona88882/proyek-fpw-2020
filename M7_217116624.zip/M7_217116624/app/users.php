<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class users extends Model
{
    protected $table='user';
    protected $primaryKey = 'email';
    protected $fillable= [
        'email','password','tipe'
    ];

    public $incrementing=false;
    public $timestamps= false;

}
