<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gambar extends Model
{
    protected $table='gambar';
    //protected $primaryKey = 'email';
    protected $fillable= [
        'gambar','tipe'
    ];

    public $incrementing=false;
    public $timestamps= false;
}
