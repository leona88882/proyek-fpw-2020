<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>login</h1>
    <form action="/checklogin" method="post">
        <?php echo csrf_field(); ?>
        alamat email <input type="text" name="email" id=""><br>
        password<input type="text" name="password" id=""><br>
        <input type="submit" value="Login">
    </form>

</body>
</html>
<?php /**PATH D:\MATERI FAI\M7_217116624\resources\views/login.blade.php ENDPATH**/ ?>