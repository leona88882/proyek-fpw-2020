<button><a href="/">Logout</a></button>
<head>
    <style>
    .grid-container {
      display: grid;
      grid-template-columns: auto auto;
      background-color: darkgreen;
      padding: 10px;
      opacity: 0.8;
    }
    .grid-item {
      background-color: rgba(255, 255, 255, 0.8);
      border: 1px solid rgba(0, 0, 0, 0.8);
      padding: 20px;
      font-size: 30px;
      text-align: center;

    }
    img{
    width:350px;
    height:350px;

    }
    </style>
    </head>
    <?php if(!is_null($result)): ?>

    <div class="grid-container" style="background-color: darkgreen">
    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($b->tipe==0): ?>
    <div class="grid-item"><img src="<?php echo e($b->link); ?>"><br>
        <input type="submit" value="Hapus gambar" style="left: 45%"></div>

    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<br>
<?php if(!is_null($result)): ?>

<div class="grid-container" style="background-color: maroon">
<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($b->tipe==1): ?>
<div class="grid-item"><img src="<?php echo e($b->link); ?>"><br>
    <input type="submit" value="Hapus gambar" style="left: 45%">
</div>

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php /**PATH D:\MATERI FAI\M7_217116624\resources\views/admin.blade.php ENDPATH**/ ?>