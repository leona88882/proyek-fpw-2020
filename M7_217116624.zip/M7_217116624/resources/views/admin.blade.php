<button><a href="/">Logout</a></button>
<head>
    <style>
    .grid-container {
      display: grid;
      grid-template-columns: auto auto;
      background-color: darkgreen;
      padding: 10px;
      opacity: 0.8;
    }
    .grid-item {
      background-color: rgba(255, 255, 255, 0.8);
      border: 1px solid rgba(0, 0, 0, 0.8);
      padding: 20px;
      font-size: 30px;
      text-align: center;

    }
    img{
    width:350px;
    height:350px;

    }
    </style>
    </head>
    @if(!is_null($result))

    <div class="grid-container" style="background-color: darkgreen">
    @foreach($result as $b)
    @if($b->tipe==0)
    <div class="grid-item"><img src="{{$b->link}}"><br>
        <input type="submit" value="Hapus gambar" style="left: 45%"></div>

    @endif
@endforeach
</div>
@endif
<br>
@if(!is_null($result))

<div class="grid-container" style="background-color: maroon">
@foreach($result as $b)
@if($b->tipe==1)
<div class="grid-item"><img src="{{$b->link}}"><br>
    <input type="submit" value="Hapus gambar" style="left: 45%">
</div>

@endif
@endforeach
</div>
@endif
